/* 

Checkout form in HTML and CSS for site having a shopping cart
Author: Pali madra
website: http://www.agilewebsitedev.com
                   and
         http://www.agileseo.net
         
*/