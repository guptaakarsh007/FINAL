package com.bookmymovie.dao.api;

import com.bookmymovie.dao.entity.Roles;

public interface RolesDao {

	public boolean insert(Roles role);
	
}
