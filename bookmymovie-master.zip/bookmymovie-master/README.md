# bookmymovie
Movie Ticket Booking is Web Application Maven project based on Java, Spring MVC, Hibernate and Spring security

This is a java based web application.

Technologies used 

Backend
--------------------------
Java,
Spring MVC,
Hibernate,
JSP,
JSTL,
Sessions,
Spring Security,

Front End
--------------------------
HTML,
CSS,
bootstrap

This is more than enough for final year project

#home page top
![profile](https://user-images.githubusercontent.com/31801009/45216110-1541d880-b2bd-11e8-95ff-f975d4f5f4dc.png)

#home page remaining
![now showing](https://user-images.githubusercontent.com/31801009/45216129-2be82f80-b2bd-11e8-96a5-ea6a9ac30092.png)

#seats selection
![seats](https://user-images.githubusercontent.com/31801009/45216189-50dca280-b2bd-11e8-9918-c8e89e48de84.png)
